# 至诚慧学课程路由扩展

本文件用于扩展 `coursework-harmonyos-submission` 的课程/活动识别，不保存账号、密码、Cookie、认证 URL 或一次性登录数据。

## 路由条目

每个条目只描述稳定的识别规则和交付规则：

```yaml
- id: zhichenghuixue-mobile-development
  platform: zhichenghuixue
  host: lms.fdzcxy.edu.cn
  course_aliases:
    - 移动终端开发
  course_url_pattern: /course/<id>/content#/
  chapter_aliases:
    - 第3章 ArkTS（下）
  activity_aliases:
    courseware:
      - 第3章 ArkTS（下）(课件)
    experiment:
      - 实验二：ArkTS 综合案例——智能家居场景
  activity_type_rules:
    courseware: [课件, 参考资料, 文档]
    experiment: [实验, 实践, 项目]
    quiz: [作业, 课后作业, 测试, 考试]
  local_layout:
    courseware: 课件
    experiment: 实验
    quiz: 课后作业
  delivery:
    experiment: upload_and_deliver
    quiz: answer_and_submit
```

上面的 `<id>` 必须从本次页面实际链接中取得；不要把示例课程 ID 或活动 ID 固化为全局规则。

## 解析优先级

1. 精确匹配用户给出的活动名称。
2. 精确匹配课程目录中的标题。
3. 使用路由条目的别名匹配。
4. 使用活动类型关键词匹配，并要求页面附件/按钮语义一致。
5. 最后才使用当前页面观察到的链接或活动 ID。

发现多个候选时，保留每个候选的标题、URL、附件名和活动类型，选择与用户章节最一致者；无法区分时停止并请求用户确认。

## 新课程扩展清单

新增平台或课程路由时只需补充：

- 主机和课程内容页模式。
- 课程、章节、活动标题别名。
- 附件类型和本地目录映射。
- 题目活动的提交按钮/结果状态语义。
- 实验或项目的命名、打包和上传规则。
- 失败时如何保留本地成果和页面证据。

平台公共流程、凭据安全、原题记录、ZIP 核验和提交后验证仍复用主 Skill，不要为每门课程复制一份完整流程。
